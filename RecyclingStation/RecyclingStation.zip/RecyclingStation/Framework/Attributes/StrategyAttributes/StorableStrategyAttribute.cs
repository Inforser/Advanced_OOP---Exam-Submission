﻿namespace RecyclingStation.Framework.Attributes.StrategyAttributes
{
    public class StorableStrategyAttribute : StrategyAttribute
    {
    }
}
