﻿namespace RecyclingStation.Framework.Attributes.StrategyAttributes
{
    using System;

    public abstract class StrategyAttribute : Attribute
    {
    }
}
