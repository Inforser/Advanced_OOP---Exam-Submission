﻿namespace RecyclingStation.IO.Writers
{
    public interface IWriter
    {
        void WriteLine(string line);
    }
}
