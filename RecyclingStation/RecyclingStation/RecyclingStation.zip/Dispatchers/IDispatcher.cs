﻿namespace RecyclingStation.Dispatchers
{
    public interface IDispatcher
    {
        string Dispatch(string input);
    }
}
