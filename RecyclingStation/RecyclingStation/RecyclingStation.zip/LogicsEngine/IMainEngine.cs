﻿namespace RecyclingStation.LogicsEngine
{
    public interface IMainEngine
    {
        void StartEventLoop();
    }
}
