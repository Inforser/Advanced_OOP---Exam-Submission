﻿namespace RecyclingStation.Framework.Attributes.StrategyAttributes
{
    public class BurnableStrategyAttribute : StrategyAttribute
    {
    }
}
