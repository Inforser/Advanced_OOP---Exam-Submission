﻿namespace RecyclingStation.IO.Readers
{
    public interface IReader
    {
        string ReadLine();
    }
}
